Welcome Star, a bright young developer with a passion for solving real-world problems. In the heart of a bustling city, Star noticed the daily struggles of commuters navigating the complex train system. Determined to make a difference, Star set out to create a user-friendly train tracking tool.

Using React and Leaflet, Star built an application that displayed live train locations and provided essential information about train lines and stations. With Entur's API, the app fetched real-time data, ensuring accuracy and reliability.

Star's creation wasn't just about tracking trains, it was about empowering commuters. With a simple interface, users could select their preferred train lines or view all trains at once. Plus, Star added GeoJSON integration, allowing users to overlay railway lines and stations on the map for better navigation.

As word spread about Star's app, commuters rejoiced. No more guessing games or missed trains , they could now plan their journeys with confidence. City planners admired Star's ingenuity, using the app to optimize transportation networks and improve urban mobility.

With Star's app, navigating the city became a breeze. Whether it was a daily commute or a weekend adventure, commuters and tourists alike relied on Star's creation to get around efficiently.

Star's journey from coder to community hero was a testament to the power of technology to make a meaningful impact on people's lives. And as trains continued to roll through the city, Star's app remained a shining beacon of innovation and accessibility for all.

Note: The trains still run at night, but since the driver is likely asleep, you wouldn't notice. But don't worry, the train didn't crash and will most probably move soon (in the morning). Sometimes the train goes to sleep at night and would like some privacy so they dissapear, dont freak out they come back in the morning or when their route starts. Some trains are a bit slow, so give them some time then you will see them move on the map :D

You should be able to zoom in when clicking on a train for easy access and displaying a pop with a little informaton about the train. You can select what line you want and see where that transport is, and you can also add stations and ralings to vizualize more. You can click on the stasjons to see the name and when it got released for use.

NB: drop down bar takes a bit time to fully load and work, and the map is a bit shy please give time for it to fully load so everything displays smoothly. If you start clicking right away it will still work but it will be very slow and you have to click multiple times, dont refresh just be patient with it.
Happy travel!

[Click here to see Star's work](https://kristiania-kws2100-2024.github.io/kws2100-exam-baambii/)


Groupwork:
Me and my group partner coded together and seperatly, later merged the codes together to create this map. There were done commits together so the commits may vary in numbers for each member seen in the commit section.
