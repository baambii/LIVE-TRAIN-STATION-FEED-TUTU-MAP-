import React, { useState, useEffect } from 'react';
import * as L from 'leaflet';
import 'leaflet-draw';
import { query } from './r11query.ts';

const trainIcon = new L.Icon({
  iconUrl:
    'https://assets.streamlinehq.com/image/private/w_200,h_200,ar_1/f_auto/v1/icons/kawaii-emoji/-travel--places/-travel--places/u+1f685-v6h3jev47j0huvsgmt2hdk.png?_a=DAJFJtWIZAAC',
  iconRetinaUrl:
    'https://assets.streamlinehq.com/image/private/w_200,h_200,ar_1/f_auto/v1/icons/kawaii-emoji/-travel--places/-travel--places/u+1f685-v6h3jev47j0huvsgmt2hdk.png?_a=DAJFJtWIZAAC',
  iconAnchor: [12, 41],
  popupAnchor: [0, -41],
  iconSize: [29, 51],
  shadowSize: [41, 41],
  shadowAnchor: [12, 41],
});

const jernbanestasjonerIcon = L.icon({
  iconUrl:
    'https://static.vecteezy.com/system/resources/previews/021/506/974/original/cute-cloud-sky-stationary-sticker-oil-painting-png.png',
  iconSize: [38, 38],
  iconAnchor: [22, 94],
  popupAnchor: [-3, -76],
});

type VehicleData = {
  line: {
    lineRef: string;
  };
  lastUpdated: string;
  location: {
    latitude: number;
    longitude: number;
  };
};

type ResponseData = {
  vehicles: VehicleData[];
};

type APIResponse = {
  data: ResponseData;
};

const BasicEnTur: React.FC = () => {
  const [data, setData] = useState<APIResponse | null>(null);
  const [map, setMap] = useState<L.Map | null>(null);
  const [markers, setMarkers] = useState<L.Marker[]>([]);
  const [selectedLine, setSelectedLine] = useState('');
  const [selectedTrain, setSelectedTrain] = useState<VehicleData | null>(null);
  const [geojsonLayers, setGeojsonLayers] = useState<{
    [key: string]: L.GeoJSON;
  }>({});

  useEffect(() => {
    const fetchData = () => {
      fetch('https://api.entur.io/realtime/v1/vehicles/graphql', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query }),
      })
       .then((response) => response.json())
       .then((data) => setData(data));
    };

    fetchData();
    const intervalId = setInterval(fetchData, 1000);

    return () => clearInterval(intervalId);
  }, []);

  useEffect(() => {
    if (!map && document.getElementById('map')) {
      const newMap = L.map('map').setView([59.9139, 10.7522], 6);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors',
      }).addTo(newMap);
      setMap(newMap);
    }
  }, []);

  useEffect(() => {
    if (map && data) {markers.forEach((marker) => marker.remove());

      const newMarkers: L.Marker<any>[] = [];

      data.data.vehicles.forEach((vehicle: VehicleData) => {
        if (selectedLine === '' || vehicle.line.lineRef === selectedLine) {
          const marker = L.marker(
            [vehicle.location.latitude, vehicle.location.longitude],
            { icon: trainIcon },
          ).addTo(map);
          marker.bindPopup(
            `<strong>${vehicle.line.lineRef}</strong><br>Last updated: ${vehicle.lastUpdated}`,
          );
          marker.on('click', () => {
            setSelectedTrain(vehicle);
          });
          newMarkers.push(marker);
        }
      });

      setMarkers(newMarkers);
    }
  }, [map, data, selectedLine]);

  useEffect(() => {
    if (map && selectedTrain) {
      map.setView(
        [selectedTrain.location.latitude, selectedTrain.location.longitude],
        13,
      );
    }
  }, [map, selectedTrain]);

  const loadGeojsonLayer = (url: string, key: string) => {
    fetch(url)
      .then((response) => response.json())
      .then((geojson) => {
        if (!map) return; 

        
        if (geojsonLayers[key]) {
          map.removeLayer(geojsonLayers[key]);
          const updatedLayers = { ...geojsonLayers };
          delete updatedLayers[key];
          setGeojsonLayers(updatedLayers);
          return; 
        }

        const newGeojsonLayer = L.geoJSON(geojson, {
          pointToLayer: function (_feature, latlng) {
            return L.marker(latlng, { icon: jernbanestasjonerIcon });
          },
          onEachFeature: function (feature, layer) {
            const properties = feature.properties;
            const popupContent = `<strong>Name:</strong> ${properties.navn}<br><strong>Type:</strong> ${properties.objtype}<br><strong>Release Date:</strong> ${properties.oppdatdato}`;
            layer.bindPopup(popupContent);
          },
        }).addTo(map);

        const updatedLayers = { ...geojsonLayers, [key]: newGeojsonLayer };
        setGeojsonLayers(updatedLayers);
      })
      .catch((error) => console.error('Error loading GeoJSON:', error));
  };

  return (
    <div
      style={{
        display: 'flex',
        height: '100vh',
        backgroundColor: '#add8e6',
        fontFamily: 'Montserrat, sans-serif',
      }}
    >
      <div
        style={{
          width: '20%',
          backgroundColor: 'transparent',
          padding: '20px',
          borderRadius: '10px',
          boxShadow: '0 0 15px rgba(0, 0, 0, 0.3)',
          fontFamily: 'Montserrat, sans-serif',
        }}
      >
        <h2
          style={{
            color: '#09365c',
            fontSize: '18px',
            marginBottom: '10px',
            fontFamily: 'Montserrat Light Alt1, sans-serif',
          }}
        >
          SKY TRAIN MAPS
        </h2>
        <div>
          <label
            htmlFor="line"
            style={{
              color: '#1a589b',
              fontSize: '16px',
              fontFamily: 'Montserrat, sans-serif',
            }}
          >
            Select line:
          </label>
          <select
            id="line"
            value={selectedLine}
            onChange={(e) => setSelectedLine(e.target.value)}
            style={{
              fontSize: '16px',
              padding: '5px',
              fontFamily: 'Montserrat, sans-serif',
            }}
          >
            <option value="">All lines</option>
            {data &&
              data.data.vehicles.map((vehicle) => (
                <option key={vehicle.line.lineRef} value={vehicle.line.lineRef}>
                  {vehicle.line.lineRef}
                </option>
              ))}
          </select>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column' }}>
          <button
            onClick={() =>
              loadGeojsonLayer('/kws2100-exam-baambii/JernbanelinjerN50.geojson', 'jernbanelinjer')
            }
            style={{
              marginTop: '10px',
              padding: '8px 16px',
              fontSize: '16px',
              backgroundColor: '#1a589b',
              color: '#fff',
              border: 'none',
              borderRadius: '5px',
              cursor: 'pointer',
              fontFamily: 'Montserrat, sans-serif',
            }}
          >
            Load Jernbanelinjer
          </button>
          <button
            onClick={() =>
              loadGeojsonLayer('/kws2100-exam-baambii/JernbanestasjonerN50.geojson', 'jernbanestasjoner')
            }
            style={{
              marginTop: '10px',
              padding: '8px 16px',
              fontSize: '16px',
              backgroundColor: '#1a589b',
              color: '#fff',
              border: 'none',
              borderRadius: '5px',
              cursor: 'pointer',
              fontFamily: 'Montserrat, sans-serif',
            }}
          >
            Load Jernbanestasjoner
          </button>
        </div>
      </div>
      <div
        id="map"
        style={{
          width: '80%',
          height: '100%',
          borderRadius: '20px',
          boxShadow: '0 0 15px rgba(0, 0, 0, 0.3)',
          marginTop: '20px',
          marginLeft: '20px',
        }}
      >
        {map !== null && (
          <h2
            style={{
              textAlign: 'center',
              color: '#ff80b3',
              fontSize: '18px',
              margin: '10px 0',
              fontFamily: 'Montserrat Light Alt1, sans-serif',
            }}
          >
            To
          </h2>
        )}
      </div>
      {selectedTrain && (
        <div
          className="sidebar-popup"
          style={{
            position: 'fixed',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            backgroundColor: '#fff',
            padding: '20px',
            borderRadius: '10px',
            boxShadow: '0 0 15px rgba(0, 0, 0, 0.3)',
            zIndex: 1000,
          }}
        >
          <h3>Selected Train: {selectedTrain.line.lineRef}</h3>
          <p>Last Updated: {selectedTrain.lastUpdated}</p>
          <button onClick={() => setSelectedTrain(null)}>Close</button>
        </div>
      )}
    </div>
  );
};

export default BasicEnTur;
