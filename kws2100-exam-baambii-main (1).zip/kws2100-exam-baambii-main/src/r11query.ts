export const query = `
  query {
    vehicles {
      line {
        lineRef
      }
      lastUpdated
      location {
        latitude
        longitude
      }
    }
  }
`;
