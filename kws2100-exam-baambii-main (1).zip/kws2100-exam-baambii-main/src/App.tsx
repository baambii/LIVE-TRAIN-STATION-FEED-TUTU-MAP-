import React from 'react';
import BasicEnTur from './BasicEnTur';

const App: React.FC = () => {
  return <BasicEnTur />;
};

export default App;
